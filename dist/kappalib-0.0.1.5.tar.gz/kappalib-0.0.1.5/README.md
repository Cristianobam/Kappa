# Kappa
Kappa is a Python 3 plotting and statistical library which performs both graphics and Frequentists analyses. Kappa aims to create better-looking graphics using Matplotlib and brings the Jamovi/Jasp analyses to python.
